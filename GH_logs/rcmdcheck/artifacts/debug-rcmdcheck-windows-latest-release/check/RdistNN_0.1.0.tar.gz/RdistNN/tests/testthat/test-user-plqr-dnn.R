skip_if_not(
  all(vapply(
    c("plqr_dnn", "plqr_demo_data"),
    exists, logical(1),
    mode = "function"
  )),
  "plqr_dnn() or required helpers not found; skipping file"
)

set.seed(321)

.make_plqr_data <- function(n = 80L, p = 2L, p_d = 2L, m = 4L, tau = 0.5) {
  demo <- plqr_demo_data(n = n, p = p, p_d = p_d, tau = tau, seed = 1)
  df <- demo$data
  X <- as.matrix(df[paste0("X", seq_len(p))])
  D <- as.matrix(df[paste0("D", seq_len(p_d))])
  mD <- as.matrix(df[paste0("mD", seq_len(p_d))])
  q <- as.numeric(df$q_oracle)
  Y <- as.numeric(df$Y)
  X0 <- matrix(rnorm(m * p), m, p)
  list(
    df = df, X = X, D = D, mD = mD, q = q, Y = Y, X0 = X0,
    beta = demo$truth$beta_true, tau = tau,
    x_cols = paste0("X", seq_len(p)),
    D_cols = paste0("D", seq_len(p_d)),
    mD_cols = paste0("mD", seq_len(p_d))
  )
}

test_that("plqr_dnn matrix API matches direct g-weighted moment identity", {
  d <- .make_plqr_data()
  out <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau,
    X0 = d$X0, distance = "l2",
    method = "exact", k = 2L, s = 3L, se = FALSE,
    return = "W"
  )

  g <- (d$tau - as.numeric(d$Y <= as.vector(d$D %*% d$beta) + d$q)) * (d$D - d$mD)
  manual <- crossprod(g, out$W)

  expect_s3_class(out, "plqr_result")
  expect_equal(dim(out$moment), c(ncol(d$D), nrow(d$X0)))
  expect_equal(unname(out$moment), unname(manual), tolerance = 1e-12)
})

test_that("data-frame and matrix APIs agree for plqr_dnn", {
  d <- .make_plqr_data(n = 70L, p = 2L, p_d = 2L, m = 3L, tau = 0.5)

  out_df <- plqr_dnn(
    data = d$df,
    x_cols = d$x_cols,
    D_cols = d$D_cols,
    q_col = "q_oracle",
    mD_cols = d$mD_cols,
    y_col = "Y",
    beta = d$beta,
    tau = d$tau,
    X0 = d$X0,
    k = 2L, s = 3L, method = "exact", se = FALSE
  )
  out_m <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau,
    X0 = d$X0,
    k = 2L, s = 3L, method = "exact", se = FALSE
  )

  expect_equal(out_df$moment, out_m$moment, tolerance = 1e-12)
})

test_that("plqr_dnn returns finite jackknife SEs with expected shape", {
  d <- .make_plqr_data(n = 50L, p = 2L, p_d = 2L, m = 2L, tau = 0.5)
  out <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau,
    X0 = d$X0,
    k = 2L, s = 3L, method = "exact", se = TRUE, jackknife = "loo"
  )

  expect_true(is.matrix(out$se))
  expect_equal(dim(out$se), dim(out$moment))
  expect_true(all(is.finite(out$se)))
  expect_true(all(out$se >= 0))
})

test_that("default jackknife mode uses fast path and matches loo reference", {
  d <- .make_plqr_data(n = 45L, p = 2L, p_d = 2L, m = 2L, tau = 0.5)

  out_default <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau, X0 = d$X0,
    k = 2L, s = 3L, method = "exact", se = TRUE
  )
  out_fast <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau, X0 = d$X0,
    k = 2L, s = 3L, method = "exact", se = TRUE, jackknife = "fast"
  )
  out_loo <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau, X0 = d$X0,
    k = 2L, s = 3L, method = "exact", se = TRUE, jackknife = "loo"
  )

  expect_equal(out_default$moment, out_fast$moment, tolerance = 1e-12)
  expect_equal(out_default$se, out_fast$se, tolerance = 1e-12)
  expect_equal(out_fast$se, out_loo$se, tolerance = 1e-12)
})

test_that("asymp method fast and loo jackknife paths agree", {
  d <- .make_plqr_data(n = 48L, p = 2L, p_d = 2L, m = 2L, tau = 0.5)

  out_fast <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau, X0 = d$X0,
    method = "asymp", k = 2L, s = 3L, se = TRUE, jackknife = "fast"
  )
  out_loo <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau, X0 = d$X0,
    method = "asymp", k = 2L, s = 3L, se = TRUE, jackknife = "loo"
  )

  expect_equal(out_fast$moment, out_loo$moment, tolerance = 1e-12)
  expect_equal(out_fast$se, out_loo$se, tolerance = 1e-12)
})

test_that("return extras are populated consistently for plqr_dnn", {
  d <- .make_plqr_data(n = 55L, p = 2L, p_d = 2L, m = 3L, tau = 0.5)
  out <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau, X0 = d$X0,
    method = "exact", k = 3L, s = 4L, se = FALSE,
    return = c("W", "ranks", "ord", "dx", "g", "ess", "neighbors")
  )

  expect_equal(dim(out$W), c(nrow(d$X), nrow(d$X0)))
  if (!is.null(out$ranks)) expect_equal(dim(out$ranks), c(nrow(d$X), nrow(d$X0)))
  if (!is.null(out$ord)) expect_equal(dim(out$ord), c(nrow(d$X), nrow(d$X0)))
  if (!is.null(out$dx)) expect_equal(dim(out$dx), c(nrow(d$X), nrow(d$X0)))
  expect_equal(dim(out$g), dim(d$D))
  expect_equal(unname(out$moment), unname(crossprod(out$g, out$W)), tolerance = 1e-12)
  expect_equal(out$ess, 1 / colSums(out$W^2), tolerance = 1e-12)
  expect_equal(dim(out$neighbors), c(3L, nrow(d$X0)))
  expect_true(all(out$neighbors >= 1 & out$neighbors <= nrow(d$X)))
})

test_that("x0 path matches corresponding single target from X0", {
  d <- .make_plqr_data(n = 44L, p = 2L, p_d = 2L, m = 4L, tau = 0.5)
  j <- 2L

  out_X0 <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau, X0 = d$X0,
    k = 2L, s = 3L, method = "exact", se = FALSE
  )
  out_x0 <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau, x0 = d$X0[j, ],
    k = 2L, s = 3L, method = "exact", se = FALSE
  )

  expect_equal(
    unname(out_x0$moment),
    unname(out_X0$moment[, j, drop = FALSE]),
    tolerance = 1e-12
  )
})

test_that("plqr_dnn validation catches shape and beta issues", {
  d <- .make_plqr_data(n = 30L, p = 2L, p_d = 2L, m = 2L, tau = 0.5)

  expect_error(
    plqr_dnn(
      X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
      beta = d$beta[-1], tau = d$tau, X0 = d$X0,
      k = 1L, s = 2L, se = FALSE
    ),
    "beta.*ncol\\(D\\)",
    ignore.case = TRUE
  )

  expect_error(
    plqr_dnn(
      X = d$X, D = d$D, q = d$q, mD = d$mD[, 1, drop = FALSE], Y = d$Y,
      beta = d$beta, tau = d$tau, X0 = d$X0,
      k = 1L, s = 2L, se = FALSE
    ),
    "same number of columns",
    ignore.case = TRUE
  )

  expect_error(
    plqr_dnn(
      X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
      beta = d$beta, tau = d$tau, X0 = d$X0,
      k = 1L, s = nrow(d$X), se = TRUE, jackknife = "loo"
    ),
    "s < n",
    ignore.case = TRUE
  )
  expect_error(
    plqr_dnn(
      X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
      beta = d$beta, tau = 1, X0 = d$X0,
      k = 1L, s = 2L, se = FALSE
    ),
    "numeric scalar in \\(0,1\\)",
    ignore.case = TRUE
  )
  expect_error(
    plqr_dnn(
      X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
      beta = d$beta, tau = d$tau, X0 = d$X0, x0 = d$X0[1, ],
      k = 1L, s = 2L, se = FALSE
    ),
    "either `X0` or `x0`",
    ignore.case = TRUE
  )
  expect_error(
    plqr_dnn(
      data = d$df,
      x_cols = d$x_cols,
      D_cols = d$D_cols,
      beta = d$beta,
      tau = d$tau,
      X0 = d$X0,
      k = 1L, s = 2L, se = FALSE
    ),
    "provide `x_cols`, `D_cols`, `q_col`, `mD_cols`, and `y_col`",
    ignore.case = TRUE
  )
})

test_that("print.plqr_result runs without error", {
  d <- .make_plqr_data(n = 35L, p = 2L, p_d = 2L, m = 1L, tau = 0.5)
  out <- plqr_dnn(
    X = d$X, D = d$D, q = d$q, mD = d$mD, Y = d$Y,
    beta = d$beta, tau = d$tau, X0 = d$X0,
    k = 1L, s = 2L, se = FALSE
  )
  txt <- capture.output(print(out))
  expect_true(any(grepl("<plqr_result>", txt, fixed = TRUE)))
})
