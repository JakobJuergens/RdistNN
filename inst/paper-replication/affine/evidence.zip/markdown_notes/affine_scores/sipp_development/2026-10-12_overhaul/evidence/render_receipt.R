# Render portable SIPP summaries using base R; no fitting or simulated data.
# Usage from the repository root:
# Rscript markdown_notes/affine_scores/sipp_development/2026-10-12_overhaul/evidence/render_receipt.R
args <- commandArgs(trailingOnly = TRUE)
script <- sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1L])
source_dir <- if (length(args)) args[1L] else dirname(script)
out <- if (length(args) > 1L) args[2L] else source_dir
dir.create(out, recursive = TRUE, showWarnings = FALSE)
est <- read.csv(file.path(source_dir, "accepted_dnn_estimates.csv"))
info <- read.csv(file.path(source_dir, "default_reconstruction.csv"))
tuning <- read.csv(file.path(source_dir, "tuning_reconstruction.csv"))
profiles <- c("age40_inc_p25", "age40_inc_p50", "age40_inc_p75")
labels <- c("$19,413", "$31,476", "$48,584")
blue <- "#17688c"; orange <- "#bc692d"
draw_intervals <- function() {
  par(mfrow = c(1, 2), mar = c(4.5, 5.3, 3.6, 1), oma = c(2, 0, 0, 0),
      family = "sans", las = 1, cex = .95)
  plot(NA, xlim = c(-44, 40), ylim = c(.5, 3.85), yaxt = "n",
       xlab = "Eligibility contrast ($1,000)", ylab = "",
       main = "Net financial assets\nNormal-reference intervals", bty = "l")
  axis(2, at = 3:1, labels = labels)
  abline(v = 0, col = "#888888", lwd = .7)
  for (k in 1:2) {
    method <- c("dnn_fullsample", "dnn_crossfit")[k]
    r <- est[est$outcome_scale == "raw_dollars" & est$method == method, ]
    r <- r[match(profiles, r$profile_id), ]
    stopifnot(nrow(r) == 3L, !anyNA(r$tau))
    y <- (3:1) + c(.11, -.11)[k]
    col <- c(blue, orange)[k]
    segments(r$ci_lo / 1000, y, r$ci_hi / 1000, y, col = col, lwd = 1.3)
    segments(r$ci_lo / 1000, y - .04, r$ci_lo / 1000, y + .04, col = col)
    segments(r$ci_hi / 1000, y - .04, r$ci_hi / 1000, y + .04, col = col)
    points(r$tau / 1000, y, pch = 16, col = col, cex = .85)
  }
  legend("topleft", c("Single fit/OOB", "Five-fold"), col = c(blue, orange),
         pch = 16, bty = "n", cex = .8, inset = c(0, -.025))
  r <- info[info$outcome_scale == "raw_dollars" & info$method == "fullsample", ]
  r <- r[match(profiles, r$profile_id), ]
  plot(NA, xlim = c(0, 110), ylim = c(.5, 3.85), yaxt = "n", xlab = "Share of frozen JK variance (%)",
       ylab = "", main = "Covariance concentration\nSingle fit/OOB", bty = "l")
  axis(2, at = 3:1, labels = labels)
  for (k in 1:2) {
    value <- 100 * r[[c("top1_jk_square_share", "top5_jk_square_share")[k]]]
    y <- (3:1) + c(.12, -.12)[k]
    rect(0, y - .1, value, y + .1, col = c(blue, "#8ab5c7")[k], border = NA)
    text(value + 1.5, y, sprintf("%.1f%%", value), adj = 0, cex = .78)
  }
  legend("topleft", c("Largest one", "Largest five"), fill = c(blue, "#8ab5c7"),
         bty = "n", cex = .8, inset = c(0, -.025))
  mtext("Income at reference-person age 40; common s = 397 and design N = 48.89.\nConcentration describes the implemented fitted covariance, not known sampling variance.",
        side = 1, outer = TRUE, line = .1, cex = .8)
}
draw_tuning <- function() {
  r <- tuning[tuning$scale == "raw_dollars" & tuning$profile_id == "age40_inc_p75", ]
  r <- r[order(r$s), ]
  par(mfrow = c(1, 3), mar = c(4.5, 4.4, 3.5, 1), oma = c(2, 0, 0, 0),
      family = "sans", las = 1, cex = .9)
  z <- qnorm(.975); lower <- (r$tau - z * r$se) / 1000; upper <- (r$tau + z * r$se) / 1000
  plot(r$s, r$tau / 1000, type = "b", pch = 16, col = blue,
       ylim = range(c(lower, upper)), xaxt = "n", xlab = "Exact DNN order s",
       ylab = "Estimate / interval ($1,000)", main = "Upper-income contrast", bty = "l")
  axis(1, at = r$s, cex.axis = .85)
  arrows(r$s, lower, r$s, upper, angle = 90, code = 3, length = .045, col = blue)
  abline(h = 0, col = "#888888", lwd = .7)
  plot(r$s, 100 * r$row2613_w, type = "b", pch = 16, col = orange, xaxt = "n",
       xlab = "Exact DNN order s", ylab = "Rank-one weight (%)",
       main = "Same nearest household", bty = "l")
  axis(1, at = r$s, cex.axis = .85)
  plot(r$s, 100 * r$row2613_jk_sq_share, type = "b", pch = 16, col = blue,
       xaxt = "n", ylim = c(74, 94), xlab = "Exact DNN order s",
       ylab = "Frozen JK square share (%)", main = "Leading deletion share", bty = "l")
  axis(1, at = r$s, cex.axis = .85)
  mtext("Complete saved order grid; nuisance signals held fixed.\nSensitivity does not select an order or measure point-target bias.",
        side = 1, outer = TRUE, line = .1, cex = .8)
}
for (name in c("intervals_and_concentration", "upper_profile_tuning")) {
  draw <- if (name == "intervals_and_concentration") draw_intervals else draw_tuning
  pdf(file.path(out, paste0(name, ".pdf")), width = 10.5, height = 3.9)
  draw(); dev.off()
  png(file.path(out, paste0(name, ".png")), width = 1890, height = 702,
      res = 180, type = if (capabilities("cairo")) "cairo" else getOption("bitmapType"))
  draw(); dev.off()
}
