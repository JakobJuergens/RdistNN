# Research recipe for the five-note SIPP packet. No nuisance fitting,
# simulated data, or changes to the application pipeline.
# Run from the repository root:
# Rscript markdown_notes/affine_scores/sipp_development/2026-10-12_overhaul/evidence/reproduce_frozen_receipt.R . /tmp/sipp_receipt_check
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) <= 2L)
root <- normalizePath(if (length(args)) args[1L] else ".", mustWork = TRUE)
out <- if (length(args) == 2L) args[2L] else tempfile("sipp_receipt_")
dir.create(out, recursive = TRUE, showWarnings = FALSE)
cache <- file.path(root, "Codes/Applications/SIPP_401k/cache/02_fit_cate_profiles.rds")
hash <- strsplit(system2("sha256sum", shQuote(cache), stdout = TRUE), " ")[[1L]][1L]
stopifnot(hash == "8eed0d3d7eda02385b2ca093d1af31e0f1d4d9eb9ce777d91d2b501fba25209d")
fit <- readRDS(cache)
d <- fit$analysis_data
n <- nrow(d)
X <- as.matrix(d[c("age_z", "asinh_inc_z")])
X0 <- as.matrix(fit$profiles[c("age_z", "asinh_inc_z")])
stopifnot(n == 9915L, !fit$run_info$smoke)
rank_weights <- function(m, s) {
  stopifnot(s >= 1L, s <= m)
  w <- numeric(m)
  w[1L] <- s / m
  for (r in seq_len(m - 1L))
    w[r + 1L] <- if (r <= m - s) w[r] * (m - r - s + 1) / (m - r) else 0
  w
}
# Columns of phi are scored under the same distance ordering.
frozen <- function(phi, s) {
  phi <- as.matrix(phi)
  w <- rank_weights(n, s)
  wm <- rank_weights(n - 1L, s)
  tau <- colSums(w * phi)
  loo <- matrix(0, n, ncol(phi))
  for (k in seq_len(ncol(phi))) {
    a <- c(wm * phi[seq_len(n - 1L), k], 0)
    b <- c(0, wm * phi[2:n, k])
    loo[, k] <- c(0, cumsum(a))[seq_len(n)] + c(rev(cumsum(rev(b)))[-1L], 0)
  }
  pv <- sweep(-(n - 1L) * loo, 2L, n * tau, "+")
  pc <- sweep(pv, 2L, colMeans(pv), "-")
  stopifnot(max(abs(colMeans(pv) - tau)) < 1e-6)
  list(w = w, tau = tau, loo = loo, pc = pc, covariance = crossprod(pc) / (n * (n - 1L)))
}
kish <- function(a) sum(a)^2 / sum(a^2)
rows <- gaps <- tuning <- components <- list()
max_weight_error <- 0
for (scale in names(fit$dnn_weights)) for (j in seq_len(nrow(X0))) {
  distance <- sqrt(rowSums(sweep(X, 2L, X0[j, ], "-")^2))
  ord <- order(distance, seq_len(n))
  raw_phi <- cbind(fit$dnn_weights[[scale]]$pseudo_outcome_fullsample,
                   fit$dnn_weights[[scale]]$pseudo_outcome_crossfit)
  phi <- raw_phi[ord, , drop = FALSE]
  z <- frozen(phi, 397L)
  cv <- z$covariance
  dg <- z$w * (phi[, 2L] - phi[, 1L])
  gaps[[length(gaps) + 1L]] <- data.frame(
    scale = scale, profile_id = fit$profiles$profile_id[j],
    se_jk_full = sqrt(cv[1, 1]),
    se_squared_full = sqrt(sum(z$w^2 * (phi[, 1L] - z$tau[1L])^2)),
    se_moment_full = sqrt(sum(z$w * (phi[, 1L] - z$tau[1L])^2) * sum(z$w^2)),
    se_jk_crossfit = sqrt(cv[2, 2]), frozen_cross_covariance = cv[1, 2],
    frozen_correlation = cv[1, 2] / sqrt(cv[1, 1] * cv[2, 2]),
    paired_gap = diff(z$tau), paired_gap_se = sqrt(cv[1, 1] + cv[2, 2] - 2 * cv[1, 2]),
    absolute_weighted_gap = sum(abs(dg)),
    treated_gap = sum(dg[d$D[ord] == 1]), control_gap = sum(dg[d$D[ord] == 0]))
  for (k in 1:2) {
    method <- c("fullsample", "crossfit")[k]
    e <- fit$nuisances[[method]]$e_hat[ord]
    expected <- fit$estimates[fit$estimates$outcome_scale == scale &
      fit$estimates$method == paste0("dnn_", method) &
      fit$estimates$profile_id == fit$profiles$profile_id[j], ]
    se <- sqrt(cv[k, k])
    stopifnot(nrow(expected) == 1L, abs(z$tau[k] - expected$tau) < 1e-7,
              abs(se - expected$se) < 1e-5)
    max_weight_error <- max(max_weight_error,
      max(abs(z$w - fit$dnn_weights[[scale]][[method]][ord, j])))
    h <- z$pc[, k]^2 / sum(z$pc[, k]^2)
    top <- which.max(h)
    original <- ord[top]
    kept <- seq_len(n) != original
    ord2 <- order(distance[kept], seq_len(n - 1L))
    deleted <- sum(rank_weights(n - 1L, 397L) * raw_phi[kept, k][ord2])
    stopifnot(abs(deleted - z$loo[top, k]) < 1e-7)
    a1 <- z$w * d$D[ord] / e
    a0 <- z$w * (1 - d$D[ord]) / (1 - e)
    sc <- z$w * (phi[, k] - z$tau[k])
    rows[[length(rows) + 1L]] <- data.frame(
      outcome_scale = scale, method = method, profile_id = fit$profiles$profile_id[j],
      tau = z$tau[k], se = se, design_ess = 1 / sum(z$w^2),
      treated_mass = sum(z$w * d$D[ord]),
      treated_kish = kish(z$w[d$D[ord] == 1]), control_kish = kish(z$w[d$D[ord] == 0]),
      ipw_treated_kish = kish(a1), ipw_control_kish = kish(a0),
      top5_absolute_score_share = sum(sort(abs(sc), decreasing = TRUE)[1:5]) / sum(abs(sc)),
      top1_jk_square_share = max(h), top5_jk_square_share = sum(sort(h, decreasing = TRUE)[1:5]),
      jk_treated_square_share = sum(h[d$D[ord] == 1]), leverage_index = sum(h^2),
      top_row_id = d$row_id[original], top_D = d$D[original], top_Y = d$Y[original],
      top_age = d$age[original], top_income = d$inc[original], top_rank = top,
      top_distance = distance[original], top_weight = z$w[top], top_propensity = e[top],
      top_frozen_signal = phi[top, k], frozen_delete_tau = deleted,
      delete_change_se_units = abs(deleted - z$tau[k]) / se)
    y <- if (scale == "raw_dollars") d$Y[ord] else d$Y_asinh[ord]
    q <- y * (d$D[ord] / e - (1 - d$D[ord]) / (1 - e))
    zb <- frozen(cbind(q, phi[, k] - q), 397L)
    cb <- zb$covariance
    stopifnot(abs(sum(zb$tau) - z$tau[k]) < 1e-7,
              abs(sum(cb) - cv[k, k]) < 1e-5 * max(1, cv[k, k]))
    components[[length(components) + 1L]] <- data.frame(
      scale = scale, method = method, profile_id = fit$profiles$profile_id[j],
      observed_Y_ipw = zb$tau[1], nuisance_adjustment = zb$tau[2],
      var_observed = cb[1, 1], var_adjustment = cb[2, 2],
      twice_covariance = 2 * cb[1, 2], var_total = sum(cb))
  }
  for (s in c(298L, 397L, 496L, 745L)) {
    zs <- frozen(phi[, 1L, drop = FALSE], s)
    h <- zs$pc[, 1L]^2 / sum(zs$pc[, 1L]^2)
    expected <- fit$tuning_grids[[scale]]$estimates
    expected <- expected[expected$s == s & expected$target_id == j, ]
    se <- sqrt(zs$covariance[1L, 1L])
    stopifnot(nrow(expected) == 1L, abs(zs$tau - expected$estimate) < 1e-7,
              abs(se - expected$se) < 1e-5)
    case <- match(2613L, d$row_id[ord])
    tuning[[length(tuning) + 1L]] <- data.frame(
      scale = scale, s = s, profile_id = fit$profiles$profile_id[j],
      tau = zs$tau, se = se, ess = 1 / sum(zs$w^2),
      r90 = distance[ord][which(cumsum(zs$w) >= .9)[1L]],
      top_jk_row_id = d$row_id[ord[which.max(h)]], jk_top1_sq_share = max(h),
      row2613_w = zs$w[case], row2613_jk_sq_share = h[case])
  }
}
stopifnot(max_weight_error < 1e-12)
write.csv(do.call(rbind, rows), file.path(out, "default_reconstruction.csv"), row.names = FALSE)
write.csv(do.call(rbind, gaps), file.path(out, "covariance_and_paired_gaps.csv"), row.names = FALSE)
write.csv(do.call(rbind, tuning), file.path(out, "tuning_reconstruction.csv"), row.names = FALSE)
write.csv(do.call(rbind, components), file.path(out, "identified_Y_and_adjustment_decomposition.csv"), row.names = FALSE)
write.csv(fit$estimates[fit$estimates$method %in% c("dnn_fullsample", "dnn_crossfit"), ],
          file.path(out, "accepted_dnn_estimates.csv"), row.names = FALSE)
write.csv(fit$profile_diagnostics, file.path(out, "accepted_support.csv"), row.names = FALSE)
# The component-data audit is a separate hdm data-contract check.
stopifnot(requireNamespace("hdm", quietly = TRUE),
          as.character(utils::packageVersion("hdm")) == fit$source$hdm_version)
pe <- new.env(parent = emptyenv())
utils::data("pension", package = "hdm", envir = pe)
p <- as.data.frame(pe$pension)
stopifnot(nrow(p) == n, identical(as.numeric(p$net_tfa), d$Y))
remainder <- p$net_tfa - p$net_n401 - p$a401
sink(file.path(out, "measurement_summary.txt"))
cat("Source: accepted 2026-07-11 cache; hdm", fit$source$hdm_version, "; no new fits.\n")
cat("N:", n, "; age40:", sum(d$age == 40), "; nonpositive income:", sum(d$inc <= 0), "\n")
cat("Eligible take-up:", mean(d$P[d$D == 1]), "; ineligible take-up:", mean(d$P[d$D == 0]), "\n")
cat("Negative assets:", mean(d$Y < 0), "; zero assets:", mean(d$Y == 0), "\n")
cat("Asset median:", median(d$Y), "; p99:", quantile(d$Y, .99), "; range:", range(d$Y), "\n")
cat("net_tfa-net_n401-a401: nonzero", sum(remainder != 0), "; range", range(remainder), "\n")
cat("net_n401-net_nifa-ira: maximum absolute discrepancy", max(abs(p$net_n401 - p$net_nifa - p$ira)), "\n")
cat("hequity-hval+hmort: maximum absolute discrepancy", max(abs(p$hequity - p$hval + p$hmort)), "\n")
cat("Full/OOB raw propensity range:", fit$nuisances$fullsample$e_hat_raw_range, "\n")
cat("Five-fold raw propensity range:", fit$nuisances$crossfit$e_hat_raw_range, "\n")
sink()
summary_path <- file.path(out, "measurement_summary.txt")
writeLines(sub("[[:blank:]]+$", "", readLines(summary_path)), summary_path)
cat("PASS: 28 defaults, 56 tuning rows, 28 explicit leading-case deletions, component identities.\n")
cat("Independent distance sorting and base-R rank recurrence; maximum weight error:", max_weight_error, "\n")
cat("No RdistNN calls, nuisance fitting or simulation. Output:", out, "\n")
