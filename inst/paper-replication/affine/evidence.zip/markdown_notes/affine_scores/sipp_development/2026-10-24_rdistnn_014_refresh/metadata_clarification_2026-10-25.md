# Preparatory tie label and current retained geometry

October 25, 2026. The accepted October 24 packet retains the preparatory
`specification$metric$tie_rule` label `input row order`. That label is stale:
[acceptance verification](evidence/acceptance_verification.json) and the
[localization derivation](evidence/localization_derivation.json) verify actual
`exact_distance_block_averaging_v1`, represented distances, averaged full
weights and recomputation after deletion for all three mechanisms.

The preparation generator now declares the actual policy for future fits.
Current fitting and diagnostic helpers require explicit, aligned retained
geometry; missing state requires refitting. The earlier README description
of a strict-rank reconstruction for geometry-free historical fits describes
the implementation at acceptance time, not current runtime support.
Historical transformed-outcome summaries remain rendering inputs.

The accepted numerical results, objects and receipt-bound evidence are
unchanged. In particular, the packet identity `rdistnn-0.1.4-20261024`, nested
fit run `paper-current` and fingerprint
`5f7203f70e52646d134089a09564a91a2aea45391df8bf1ef2dc8b93bfc836a2`
remain intact. Editing the accepted specification would change that
fingerprint and require a new packet and receipt chain; no such change is
made by this maintenance correction.
