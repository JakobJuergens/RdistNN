# Final verification

October 24, 2026. Base paper commit: `f99105f`. Released package source:
`4acade538f7ac8a88fe7f837b1673ebc17daa17a` (`v0.1.4`).

## Computation and preservation

The complete fresh fit uses all 9,915 households and the original declared
forest settings, folds, seed and controls. All propensity predictions, both
outcome-mean arrays, clipping flags, row IDs and AIPW signals are identical
to the original accepted run for all three prediction mechanisms. All 21
default and 168 order-grid rows were independently reconstructed. None
changes whether its interval includes zero. New figures and all 13 table
fragments were generated from the portable packet through their owner.

The original fresh fit/manifest/model files are preserved. The derived fit
changes no pre-existing contents and adds only checked localization geometry
and explicit derivation provenance. Historical empirical packets, simulation
code/evidence/tables, coupled sources and all formal mathematical blocks
remain unchanged: 324 protected tracked files and 266 unrelated tracked PDFs
passed byte-preservation checks. All 21 portable packet file hashes passed.
No package source or released tag was modified.

## Verification results

- Frozen-diagnostic tests: 56 assertions, including direct surviving-group
  comparisons, an all-tied sample, tampered geometry and missing policy.
- Eight-order sensitivity tests: 16 assertions.
- Publisher tests: 56 assertions, including historical publication, refreshed
  values, corrupted input, validation rejection and missing deletion checks.
- Run-store tests: 25 assertions. Export tests: 13 assertions.
- Prediction-path tests: 56 assertions; intentional exact-distance-tie notices
  remain visible. Fit-helper, CLI and profile-diagnostic smoke tests passed.
- Independent read-only review checked the groupwise deletion formula against
  760 explicit-survivor cases (reported maximum error 4.44e-16). It approved
  the implementation and identified stale dollar/share prose, all corrected.
- Python affine CI checks: 21 tests, PASS.
- References: 140 labels and 18 external references, PASS.
- Legacy proof-gap manifest: 54 gaps and 12 appendix files, PASS.
- Portable publisher `--check` and source/PDF metadata `--check`: PASS.
- Local documentation links: 36 checked. No package-version text was added to
  active paper content.

## Artifacts

The review paper and supplement remain 79 and 26 pages. Publishing remains
37 plus 13, or 50 consecutive pages. Both owner builds and the publishing
builder passed PDF integrity checks, and extracted source compilation settled
after three paper passes and two supplement passes. The final logs have no
overfull boxes or unresolved references. All three source figures passed qpdf
and embedded-font checks. Affected publishing pages were visually inspected
for the tie explanation, refreshed tables, numerical prose and availability.

The availability declaration now points to the paper repository, where the
updated helpers and evidence accompany the paper. The immutable 0.1.4 package
bundle retains its older diagnostic snapshot; synchronizing a future package
bundle remains separate from this completed paper-side refresh.

Detailed process logs, original executable identities, source-package checks,
rendered inspection pages and preservation records are retained locally under
`/tmp/condz-rdistnn-prearxiv-20261024/`. The concise portable dependency results
are in [dependency_comparison.json](dependency_comparison.json); raw observation
arrays and fitted forests are excluded from the tracked evidence packet.
