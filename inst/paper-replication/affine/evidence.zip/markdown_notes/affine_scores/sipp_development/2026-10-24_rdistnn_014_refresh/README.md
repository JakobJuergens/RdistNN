# SIPP refresh and package dependency comparison

October 24, 2026. The user requested a fresh SIPP application with released
RdistNN 0.1.4 and paper prose describing exact-distance weight averaging without
package-version or development-history language.

## Fresh fit and comparison

The production fit uses all 9,915 households, the original adjustment set and
seven age-40 income profiles, raw net financial assets, 2,000-tree nuisance
forests, five folds, seed 20260709 and four forest threads. It uses R 4.6.1,
hdm 0.3.2, grf 2.6.1 and an isolated installation from released tag `v0.1.4`,
source `4acade538f7ac8a88fe7f837b1673ebc17daa17a`.
The [fit manifest](evidence/fit_manifest.json) pins installed executable hashes.

All full-fit, OOB and held-out propensity predictions and AIPW signals are
identical to the accepted original run. The changes therefore arise from
averaging assigned rank weights among observations at exactly equal represented
distance, including after each deletion.

| Comparison | Largest absolute change, 1991 dollars |
| --- | ---: |
| Default CATE estimate, 21 rows | 13.91 |
| Default standard error, 21 rows | 0.56 |
| Default interval endpoint, 21 rows | 14.57 |
| CATE estimate, all 168 order rows | 16.35 |
| Standard error, all 168 order rows | 1.19 |

No default or order-grid interval changes whether it includes zero. All nine
interior default intervals still include zero. Default OOB estimates at the
25th, 50th and 75th income percentiles are approximately $2,758.94, $5,931.72
and -$3,405.04. The rounded main-text interpretation remains unchanged;
the generated tables retain the refreshed last digits.

The [default comparison](evidence/accepted_comparison.csv) and
[order comparison](evidence/localization_comparison.csv) retain every row.
The [verification](evidence/acceptance_verification.json) records common
weights, unchanged signals and independent reconstruction. The original
code-overhaul and historical transformed-outcome packets are unchanged.
The supplement continues to label the transformed target historical.

## Independent diagnostics and original-run preservation

The released installed launcher completed the fresh forest fit, but its
bundled independent diagnostics still assumed strict input-order ties and
stopped on the changed weights. Its original fresh fit, terminal manifest
and models are preserved under the ignored cache directory
`Codes/Applications/SIPP_401k/cache/rdistnn-0.1.4-20261024/runs/paper-current/`.

An explicitly derived analysis copy adds represented distance arrays and the
actual fitted averaging policy. It checks all three methods against the exact
released public estimator using the saved signals; no forests are refitted
and no estimate, prediction or saved weight is changed. Both input/output
hashes and reconstruction errors are in the
[derivation receipt](evidence/localization_derivation.json).

The paper's current helpers retain this geometry in future fits. Their
independent calculation averages full weights by exact distance group. After
deleting a member, preceding groups use unchanged retained ranks, following
groups shift down one rank, and the member's group averages over its survivors.
Group prefix/suffix sums compute all deletions, component and paired covariance,
and concentration without nuisance fitting or calls to the package jackknife.
Tests compare these results with explicit survivors, including an all-tied sample.

Historical fits without the new geometry retain their strict reconstruction.
New geometry participates in fingerprints and is checked against reporting
coordinates. The publisher requires explicit independent averaging/deletion
checks for refreshed packets; historical publication retains its original
equality checks.

## Manuscript and replication scope

The paper describes averaging directly, including zero table entries and
recomputation after deletion. It retains continuous distances as a theoretical
assumption; inference under persistent ties is not established. Constant
effective size across profiles is qualified to distinct distances, while the
application reports its effective sizes as approximately 48.9. The generic
integer-age support limitation remains explicit. No package-version or
development-process explanation is introduced into the paper.

Publication is owned by `07_render_affine_manuscript.R` and the
[hash receipt](receipt.json). The immutable released package bundle is not
modified by this paper-side refresh. A future bundle synchronization must
incorporate these helpers and evidence; current paper-repository entrypoints
work with RdistNN 0.1.4.

## Simulation dependency check

The [dependency comparison](dependency_comparison.json) records twelve frozen
fixed-Euclidean implementation cases covering C0/C2, both tested
orders and oracle/full/five-fold predictions. The exact historical simulation
DLL and source identities were verified. All 96 comparison records pass the
predeclared budgets in compiled and forced-R modes, with differences on the
order of machine precision. The study constructs its own rank tables and uses
the public full-rank deletion engine; the high-level tie policy does not
change that path. No simulation rerun is indicated.

This is implementation validation, not reconstruction of all production draws
or a new 10,000-draw study. Raw comparison logs and installation identities
remain under `/tmp/condz-rdistnn-prearxiv-20261024/`; observation-level inputs
are excluded from this tracked packet. The [final verification](verification.md)
records completed tests, preservation checks and document builds.
