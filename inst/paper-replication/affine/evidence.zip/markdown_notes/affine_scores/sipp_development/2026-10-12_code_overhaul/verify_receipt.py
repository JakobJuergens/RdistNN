#!/usr/bin/env python3
"""Verify portable SIPP receipt hashes and fitted covariance identities."""
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path


def close(actual, expected):
    if not math.isclose(actual, expected, rel_tol=1e-8, abs_tol=1e-5):
        raise AssertionError(f"Numeric identity failed: {actual} != {expected}")


def verify():
    root = Path(__file__).resolve().parent
    receipt = json.loads((root / "receipt.json").read_text())
    for name, expected in receipt["files"].items():
        actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
        if actual != expected:
            raise AssertionError(f"Hash mismatch: {name}")
    evidence = root / "evidence"

    def read(name):
        with (evidence / name).open(newline="") as stream:
            return list(csv.DictReader(stream))

    for name, expected in receipt["csv_row_counts"].items():
        if len(read(name)) != expected:
            raise AssertionError(f"Row count mismatch: {name}")
    selection = json.loads((evidence / "selection.json").read_text())
    sensitivity = json.loads((evidence / "sensitivity.json").read_text())
    acceptance = json.loads((evidence / "acceptance_verification.json").read_text())
    if not (selection["fit_fingerprint"] == sensitivity["fit_fingerprint"] ==
            acceptance["fit_fingerprint"] == receipt["fit_fingerprint"]):
        raise AssertionError("Fit fingerprints differ")
    if sensitivity["retained_default"] != 397 or not sensitivity["signals_frozen"]:
        raise AssertionError("Sensitivity changed the default or signals")
    for manifest in (selection, sensitivity):
        if manifest["purpose"] != "empirical":
            raise AssertionError("Unexpected validation export")
        for name, expected in manifest["files"].items():
            if hashlib.sha256((evidence / name).read_bytes()).hexdigest() != expected:
                raise AssertionError(f"Export hash mismatch: {name}")

    def key(row, method=None):
        return row["outcome_scale"], row["profile_id"], method or row["method"]

    estimates = {key(r): r for r in read("estimates_all.csv")}
    information = {key(r): r for r in read("information.csv")}
    components = defaultdict(float)
    for row in read("component_covariance.csv"):
        components[key(row)] += float(row["covariance"])
    for row in read("covariance_routes.csv"):
        estimate = estimates[key(row)]
        close(float(row["variance_jackknife"]), float(estimate["se"]) ** 2)
        close(components[key(row)], float(estimate["se"]) ** 2)
        close(float(information[key(row)]["tau"]), float(estimate["tau"]))
    for row in read("paired_training.csv"):
        a = estimates[key(row, row["method_1"])]
        b = estimates[key(row, row["method_2"])]
        close(float(row["gap"]), float(b["tau"]) - float(a["tau"]))
        close(float(row["gap"]), float(row["treated_gap"]) + float(row["control_gap"]))
        variance = float(a["se"]) ** 2 + float(b["se"]) ** 2 - 2 * float(row["covariance"])
        close(float(row["paired_gap_se"]) ** 2, variance)
    for row in read("localization_all.csv"):
        close(float(row["nearest_weight"]), int(row["s"]) / acceptance["n"])
        if int(row["s"]) == 397:
            estimate = estimates[key(row)]
            close(float(row["tau"]), float(estimate["tau"]))
            close(float(row["se"]), float(estimate["se"]))
    selected = read("estimates_selected.csv")
    if not all(float(r["ci_lo"]) < 0 < float(r["ci_hi"]) for r in selected):
        raise AssertionError("Default interval receipt differs")
    print("SIPP receipt verified: all file hashes, row counts, covariance/paired "
          "identities, 168 localization rows and retained default 397.")


if __name__ == "__main__":
    verify()
