# SIPP application code overhaul and observed-data acceptance

The application now makes literal full-fit, single-fit/OOB and five-fold
nuisance predictions separately observable, with the same final DNN weights.
A complete 9,915-household raw-dollar acceptance run reproduces the historical
OOB and five-fold signals exactly. A subsequent saved-signal order exploration
confirms that strong localization amplifies the upper-income profile's
dependence on one large residual. It does not establish an optimal order or
validate causal interpretation or normal-reference coverage.

This is the implementation receipt for the [five-note design](../../../archive/topics/affine_submission/empirical_planning/01_narrative_and_research_strategy.md).
The design's additional substantive specifications remain proposals except
where explicitly described below. The manuscript continues to use its accepted
historical illustration. No manuscript, simulation program, accepted table or
historical flat cache was changed in this implementation.

## Implemented application workflow

The [application README](../../../../Codes/Applications/SIPP_401k/README.md)
documents the runnable commands and option contracts. Preparation now declares
the adjustment set, reporting coordinates, literal or sample-derived profiles,
metric scales and outcome definition. Required missingness follows the chosen
specification; original household row IDs precede filtering and remain stable.
Baseline feature order and preprocessing are preserved.

The historical reporting covariates were correctly standardized: age and
asinh income have sample mean zero and sample SD one, and every profile uses
the same constants. Here those constants are age center 41.0602118003 and SD
10.3445048635, and asinh-income center 10.9896082540 and SD 0.7763510525.
Sample-derived scales and integer-age geometry still require the manuscript's
qualification relative to a fixed continuous reporting construction. The
forest adjustment variables need not each be standardized.

Full-fit and OOB paths use the same propensity and arm-specific outcome
forests. Full-fit explicitly predicts at all training covariates. OOB uses
own-observation exclusion for the propensity and the observed outcome arm;
opposite-arm predictions are ordinary newdata predictions. Held-out paths save
fold training and evaluation IDs. Every path retains raw and clipped
propensities, both fitted means, their contrast, both arm residual corrections
and the total AIPW signal. The historical method named dnn_fullsample remains
labeled single-fit/OOB when an old cache is read. A new dnn_fullsample denotes
literal all-tree predictions.

Run directories are reserved before fitting and record completed or failed
terminal status. They reject collisions and overwrite attempts. Fitted models
are saved separately from portable fitted arrays. Manifests hash actual
installed package files, application source, selected rows, data and outputs;
a sibling source checkout is recorded separately in fit run metadata. The
saved-fit fingerprint includes every fitted and semantic input consumed by
diagnostics. Exporters reject smoke/subsample fits unless explicitly permitted
and labeled as validation.

Frozen diagnostics independently reconstruct exact k=1 rank weights and
retained-sample deletion estimates, check every score component and stored
tuning row, and report component cross-covariances, paired training gaps,
alternative variance routes, arm information, clipping mass and jackknife
concentration. The separate order explorer changes weights while holding the
saved nuisance predictions fixed. Neither analysis refits a learner.

## Full-population acceptance

Run ID: 2026-10-12-affine-code-acceptance-raw-v1. Local outputs reside under
Codes/Applications/SIPP_401k/cache/runs/ with that ID. The completed fitting
manifest records October 13, 2026, 03:13:38–03:16:13 UTC, which is October 12
locally. The run uses raw net financial assets in 1991 dollars, baseline
adjustment, age/income reporting, 2,000 trees, five folds, seed 20260709,
four threads, k=1, lambda 0.4 and default s=397. The stored tuning grid contains
s=298,397,496,745. R is 4.3.3; hdm is 0.3.2, grf is 2.6.1 and RdistNN is 0.1.0.

The [fit manifest](evidence/fit_manifest.json) preserves fitting-time hashes.
The [acceptance verification](evidence/acceptance_verification.json) records
exact OOB/five-fold signal reproduction, identical held-out propensities and
fold IDs, identical weights across all three mechanisms, complete component
and grid validation, and unchanged historical cache hashes. The existing fit
and diagnostic caches retain SHA256 values
8eed0d3d7eda02385b2ca093d1af31e0f1d4d9eb9ce777d91d2b501fba25209d and
cf8081ecbfece06389305456319eedb679eb4877fd1ae2b2aff76ca1569aec3f.

Default point estimates and frozen-score jackknife SEs are:

| Age-40 income profile | All-tree estimate (SE) | Single-fit/OOB estimate (SE) | Five-fold estimate (SE) |
| --- | ---: | ---: | ---: |
| $19,413 | $3,123 ($2,259) | $2,763 ($2,668) | $2,959 ($2,638) |
| $31,476 | $6,224 ($4,726) | $5,933 ($5,391) | $6,826 ($5,856) |
| $48,584 | −$2,668 ($16,446) | −$3,419 ($18,430) | −$3,523 ($18,867) |

All nine displayed default normal-reference intervals include zero. All-tree
SEs are roughly 11–15% below OOB SEs, but that does not show improved coverage
or less target bias. OOB/five-fold paired gap SEs are $318, $667 and $907;
their fitted covariance correlations are 0.993, 0.996 and 0.999. Agreement
therefore shares substantial fitted variation and is not independent
confirmation of an effect.

The upper profile has largest centered jackknife-square shares of 83.20%,
83.05% and 83.84% across all-tree, OOB and five-fold paths. All identify source
row 2613: an ineligible household, age 40, income $48,402 and net financial
assets $232,600. Its local rank is one and weight is 397/9915=4.004%.
OOB propensity is 0.494, so its large contribution does not come from a
near-zero treatment probability. Its fitted control mean is $23,337 and
control residual correction is −$413,491. Literal full-fit raises its control
mean to $38,727 and reduces that correction to −$354,323; five-fold predicts
$15,464 and gives a correction of −$427,619. The
[saved component rows](evidence/upper_dominant_case_components.csv) preserve
this attribution. Frozen-score deletion changes the upper estimate to
$12,334, $13,377 and $13,753, respectively. This is an observed-case diagnostic,
not a full learner-refit deletion exercise or a bias estimate.

## Smaller-s exploration

At k=1, the nearest weight is s/n. Reducing s broadens the neighborhood and
directly dilutes the nearest high-residual household. The exploration covers
all seven profiles, all three mechanisms and eight orders; its
[168-row export](evidence/localization_all.csv) retains favorable and adverse
findings. The [sensitivity manifest](evidence/sensitivity.json) records the
unchanged fit fingerprint, frozen signals, helper source hash and retained
default 397.

For the upper profile, single-fit/OOB results are:

| s | Estimate | SE | Effective size | Radius containing 90% weight | Largest jackknife-square share |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 99 | $1,899 | $5,720 | 198.3 | 0.2108 | 51.7% |
| 149 | $506 | $7,829 | 131.7 | 0.1838 | 62.8% |
| 198 | −$215 | $9,895 | 98.9 | 0.1406 | 69.9% |
| 248 | −$849 | $12,016 | 78.8 | 0.1179 | 74.8% |
| 298 | −$1,571 | $14,155 | 65.4 | 0.1081 | 78.4% |
| 397 | −$3,419 | $18,430 | 48.9 | 0.1031 | 83.1% |
| 496 | −$5,769 | $22,739 | 38.9 | 0.0978 | 85.9% |
| 745 | −$13,128 | $33,643 | 25.6 | 0.0921 | 90.0% |

The same household remains the largest contributor throughout. Its weight
falls to 0.998% at s=99. The standardized radius roughly doubles, and the
90%-radius household range broadens from ages 39–41 and incomes $45,231–$52,350
at s=397 to ages 38–42 and incomes $41,535–$56,994 at s=99. These are marginal
coordinate ranges among observed households within that radius, not a
rectangular region or a confidence set. IPW-factor Kish sizes rise from
24.4/21.9 to 101.0/84.6 for eligible/ineligible households. The original
concentration is consistent with aggressive localization amplifying a heavy
asset residual, rather than being explained solely by propensity instability.

Concentration does not improve uniformly: the lower profile's largest share
increases from 26.3% at s=397 to 42.2% at s=99, despite a smaller SE. The median
share changes from 62.4% to 51.4%, with nonmonotonic intermediate behavior.
Some broader-neighborhood lower/median normal-reference intervals exclude
zero. Those exploratory intervals are retained and are not a reason to choose
an order. Spatial drift and the acceptable extent of pooling remain unmeasured.
Orders 149 and 198 are useful sensitivity choices for the next economic
specification pass; no replacement default is selected here.

## Portable evidence and verification

The [interval display](evidence/raw_dollars_intervals.pdf),
[concentration display](evidence/raw_dollars_concentration.pdf) and
[order display](evidence/raw_dollars_localization.pdf) use the same interior
profiles. The default exporter retains all 21 profile/mechanism estimates,
84 tuning reconstructions, 21 paired comparisons, 63 component means and 189
component covariance entries. The PDF displays passed qpdf and visual review.
Selection is explicit in [selection.json](evidence/selection.json); the full
tables remain available beside it.

All 11 standalone application test files passed on the final scientific code
snapshot. Coverage includes legacy entry points, controlled prediction
membership, score/component identities, all tuning rows, original row IDs,
run/output collisions, corrupt fingerprints and validation labels. The new
income-only positive-asset and exact-age40/IRA capped-dollar branches passed
small end-to-end validation fits. They have not been run as substantive
full-production alternatives. A missing-history-cache check skips only the
historical golden test and keeps grid-corruption regressions active.
The required documentation proof-gap check passed with 54 gaps and 12 appendix
files; this historical manifest was not edited.

Two captured source files differ from the final code: estimation_helpers.R
gained explicit lambda CLI options, and affine_export.R improved plot labels
and margins. The fitting configuration and learner implementations were not
changed after acceptance. The standalone localization module was added later
and is hashed in its own analysis manifest. Final source/test hashes and test
log hashes are preserved separately in
[verified_source_hashes.json](evidence/verified_source_hashes.json) and
[test_receipt.json](evidence/test_receipt.json). The fitting manifest has not
been rewritten to imply that the initial whole application matches the later
CLI/render snapshot.

Verify the published files and portable numeric identities without local
caches or a new fit:

~~~bash
python3 markdown_notes/affine_scores/sipp_development/2026-10-12_code_overhaul/verify_receipt.py
~~~

Reproduce the raw-dollar fit with the current application using a fresh ID,
then run 03, 05 and 06 as described in the application README. Use
--outcomes=raw and --orders=99,149,198,248,298,397,496,745 for this receipt's
endpoint and sensitivity grid. Large RDS/model files remain ignored local
outputs; the committed receipt publishes their identities and small portable
results. Additional adjustment sets, fixed literal profiles/scales, alternative
endpoints and one-dimensional targets now have code support; their substantive
evaluation and any manuscript promotion remain subsequent work.
