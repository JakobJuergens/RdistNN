# Full 10000-repetition affine production outputs

Completed and integrity-audited October 12, 2026. All four profiles ran
10000 main repetitions per cell with fixed scientific settings. The 28
profile-cells contain 2516400 rows, including 56400 preplanned control rows.
There are 10000 common independent draw families. The 480000 duplicated
DNN rows are exact copies across profiles and supply no additional independent
draws. This receipt records completed numerical production; it does not
promote evidence to the manuscript or verify asymptotic assumptions.

| Profile | Main repetitions | Actual rows | Validated chunks |
| --- | ---: | ---: | ---: |
| DNN | 10000 | 896000 | 1250 |
| Kernel comparison | 10000 | 1080000 | 1250 |
| M3 endpoint | 10000 | 60400 | 1250 |
| Settings | 10000 | 480000 | 1250 |

Every process exited with code zero. The [audit](audit.json) verifies all
planned keys, chunk payload hashes and exact chunk/raw correspondence,
source/dependency/configuration hashes, raw/summary hashes, common production
seeds and disjoint pilot seeds. Bias, SD, coverage and interval length were
independently recalculated from raw rows. Duplicated DNN estimates,
coefficients, information scales, seeds and all variance/interval fields
agree exactly. Zero estimation, diagnostic and variance-availability failures
were found. Gram-event failures are distinct and remain in the results:
C0/C1 at n=4096 each have 21/10000 failures. M3 has no intensive gap diagnostic
subset, as preplanned. Selected diagnostics are finite measurements.

The [completion note](../11_full_10000_production.md) records resource use,
first findings and interpretation. The [monitoring receipt](provenance/monitoring.json)
records 56 health checks about 15 minutes apart. Process receipts preserve
sampled peak RSS and wall time; manifest CPU measurements cover family work.

| File | Contents |
| --- | --- |
| [performance.csv](performance.csv) | All methods, applications, localizers and variance routes, including Monte Carlo uncertainty |
| [variance_pairs.csv](variance_pairs.csv) | Paired variance-route coverage and length differences, gains/losses and MCSE |
| [localizer_pairs.csv](localizer_pairs.csv) | Paired DNN/kernel comparisons |
| [training_pairs.csv](training_pairs.csv) | Paired full/pooled-five-fold comparisons |
| [paired.csv](paired.csv) | Normalized full-minus-cross-fit and full-minus-oracle gaps |
| [spatial_decomposition.csv](spatial_decomposition.csv) | Spatial drift and nuisance-remainder decomposition |
| [covariance_ratios.csv](covariance_ratios.csv) | Feasible/oracle covariance ratios with explicit reference scales |
| [gram_events.csv](gram_events.csv) | Full-fit Gram-event frequencies and probability intervals |
| [error_counts.csv](error_counts.csv) | Status counts, including all success and failure categories |
| [provenance/production_cells.csv](provenance/production_cells.csv) | Resolved production cells and deterministic settings |
| [provenance/proposal.json](provenance/proposal.json) | Frozen preparation proposal and expected counts |
| [SHA256SUMS](SHA256SUMS) | Hashes of this portable export |

The provenance folder also preserves each configuration, run manifest,
process receipt, common seed map, supervisor receipt and all health checks.
Frozen preparation status describes the pre-launch snapshot; completed run
manifests and process receipts establish execution status.

The later [production analysis packet](../production_analysis/README.md)
adds genuine QQ curves, fresh-risk and covariance-component moments and new
paired contrasts extracted from the same saved results, without estimation.

Raw RDS files, full diagnostics, timing arrays, session information and sealed
chunks remain at:
`/home/jakob/research/02_code/simulations_cond_z_est/affine_full_10000_20261011_v1`.

From the repository root, reproduce the completed-file integrity audit and
summary export in a new directory:

```bash
Rscript Codes/Simulations/affine_scores/campaign_tools/audit_production.R \
  /home/jakob/research/02_code/simulations_cond_z_est/affine_full_10000_20261011_v1 \
  NEW_EXPORT_DIR
```

The audit runs no estimator and refuses an existing export directory. Its
script hash is recorded in audit.json. The portable provenance copies and
this index supplement the direct audit export. Historical pilots, empirical
outputs, RdistNN source and manuscript inputs remain unchanged.
